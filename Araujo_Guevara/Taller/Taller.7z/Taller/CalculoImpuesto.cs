﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;

namespace Taller
{
    public class CalculoImpuesto
    {
        public CalculoImpuesto()
        {

        }
        public double Sueldo(double sueldo)
        {
            if (sueldo < 0)
            {
                return 0;
            }
            else
            {
                double sueldoTotal = sueldo * 0.9055 * 12;
                return sueldoTotal;
            }
            //return sueldoFinal;
        }
        public int calcularImpueto(int sueldo)
        {
            //nt sueldoFinal=Sueldo(float sueldo);
            if(sueldo>=0 || sueldo<11290)
            {
                return 0;
            }
            if (sueldo >= 11290 || sueldo < 14390)
            {
                double sueldoExcedente = (sueldo - 11290)*0.05;
            }
            if (sueldo >= 14390 || sueldo < 17990)
            {
                double sueldoExcedente = (sueldo - 11290) * 0.05;
            }
            return 0;
        }
    }
}
